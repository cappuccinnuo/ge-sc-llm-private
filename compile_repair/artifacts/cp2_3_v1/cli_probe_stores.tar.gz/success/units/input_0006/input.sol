pragma solidity >=0.4.24 <0.9.0;
// caf� latin-1 comment
contract C { function f() public pure returns (uint) { return 1; } }
